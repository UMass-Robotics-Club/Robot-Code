
import grpc
from concurrent import futures
import time
import robot_call_pb2
import robot_call_pb2_grpc

class RobotCallServicer(robot_call_pb2_grpc.RobotCallServicer):
    def SendCommand(self, request, context):

        print(f"Received command at {request.timestamp}:")
        print(f"Elbow angle: {request.left_shoulder_lower}")
        print(f"Forearm angle: {request.right_shoulder_lower}")
        print(f"Gripper position: {request.forearm_right_lower }")

        # Simulate success
        return robot_call_pb2.CommandResponse(success=True, message="Command executed successfully")
def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    robot_call_pb2_grpc.addRobotControlServicer_to_server(RobotControlServicer(), server)
 
    server.add_insecure_port('[::]:50051')
    print("Server started on port 50051...")
    server.start()
    server.wait_for_termination()

if __name__ == '__main__':
    serve()

    #upper arm, lower arm and , what of them do I need the lenghts? angles?