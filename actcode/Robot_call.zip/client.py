import grpc
import robot_control_pb2
import robot_control_pb2_grpc
import time

def send_command(stub):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    command = robot_control_pb2.RobotCommand(
        
         forearm_right_lower= 0,
       right_shoulder_lower= 0,
        left_shoulder_lower= 0,
    )

    response = stub.SendCommand(command)
    print(f"Response from server: {response.message}")

def run():
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = robot_control_pb2_grpc.RobotControlStub(channel)
        send_command(stub)

if __name__ == '__main__':
    run()
